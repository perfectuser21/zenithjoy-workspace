#!/usr/bin/env python3
"""
preflight.py — Agent 开机环境自检 + 自愈层（Path 4 微信 RPA 前置体检）。

面对千万台杂乱客户机，agent 启动时先跑这套"体检"：逐项 **检测 → 能修的自动修 →
修不了的给明确提示**，最后产出报告（打印 + 写本地 JSON + best-effort 上报中台，
让运营在 Dashboard 远程看，不用 SSH 进客户机）。

8 个检测项（每项 detect → fix → 修不了 prompt，产出 {name,status,detail}）：
  1. OS/交互会话    —— 是 Windows + 有活动桌面会话（不可自愈）
  2. 微信安装        —— Weixin.exe 在不在；不在 → 下载 4.1.8 静默装
  3. 微信版本        —— >=4.1.9 → 卸载 + 装 4.1.8；=4.1.8 → ok
  4. 锁更新          —— WeixinUpdate.exe 改名 .disabled + 防火墙出站封禁（幂等）
  5. 微信登录态      —— 未登录 → 拉起微信 + 提示扫码
  6. Python+pywinauto—— import 测试；失败 → 提示重装 agent
  7. UIA/讲述人激活  —— 静默激活讲述人后能否读到主窗口
  8. 中台连通        —— GET <middleware>/health；不通 → 提示查网络

跨平台纪律：pywinauto / windll / subprocess 真实自愈动作全在 **函数体内** import +
try/except 包裹；**顶层 import 在 mac/linux 也能成功**（供 CI 单测）。mac 上 windll
不可用 → 优雅降级为 warn/failed，绝不崩。自愈动作全部幂等、可重复跑。

CLI：
  python preflight.py [--middleware-url URL] [--dry-run]
  --dry-run：只检测不自愈、不下载、不卸载（给 CI / mac 跑）。
  退出码：全 ok 或仅 warn → 0；有 failed → 非0（start.bat 可自行决定是否仍继续）。
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Windows GBK 控制台无法编码 emoji（✅ ⚠️ ❌），强制 UTF-8 输出避免 UnicodeEncodeError 崩溃
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

sys.path.insert(0, str(Path(__file__).resolve().parent))

# find_weixin 顶层零 pywinauto/windll import，安全复用其纯函数与寻址 API。
from find_weixin import (  # noqa: E402
    MIN_BLOCKED_VERSION,
    WEIXIN_EXE_DEFAULT,
    _parse_version,
    get_weixin_version,
)

# ─── 常量 ────────────────────────────────────────────────────────────────────

# 微信 4.1.8 安装包下载源（按序尝试：先我们 COS 加速，再官方回退）。
WECHAT_DOWNLOAD_URLS = (
    "https://zenithjoy-static-1333590468.cos.accelerate.myqcloud.com/install-pack/wechat/WeChatWin_4.1.8.exe",
    "https://dldir1v6.qq.com/weixin/Universal/Windows/WeChatWin_4.1.8.exe",
)

# 微信 4.x 官方安装根目录（版本号子目录名会变，自愈时用递归搜文件）。
WEIXIN_INSTALL_ROOT = r"C:\Program Files\Tencent\Weixin"

# 下载体积下限：正常 4.1.8 安装包 >100MB，低于此视为下载残缺。
MIN_DOWNLOAD_SIZE = 100 * 1024 * 1024

# 本地报告落盘路径（运营 SSH 直接读；与 listen_chat 的 zj-*.log 同目录习惯）。
PUBLIC_DIR = os.environ.get("PUBLIC", r"C:\Users\Public")
PREFLIGHT_JSON_PATH = os.path.join(PUBLIC_DIR, "zj-preflight.json")

# 下载到的安装包临时落点。
_INSTALLER_TMP = os.path.join(PUBLIC_DIR, "WeChatWin_4.1.8.exe")

# 状态 → 人类可读图标。
_STATUS_ICON = {"ok": "✅", "fixed": "🔧", "warn": "⚠️", "failed": "❌"}

# 检测项的稳定名称（报告/看板按此对齐）。
# 注意：elevation 追加在末尾（保证既有按下标引用的检测项不串位），
# 但在 run_all_checks 的执行序列里排在 os_session 之后靠前（它影响后面 UIA/登录项成败）。
CHECK_NAMES = (
    "os_session",
    "wechat_installed",
    "wechat_version",
    "lock_update",
    "wechat_login",
    "python_pywinauto",
    "uia_narrator",
    "middleware_health",
    "elevation",
)


# ─── 纯逻辑函数（CI 单测锚点，顶层零 Windows 依赖）──────────────────────────────


def decide_wechat_action(version_tuple: Optional[Tuple[int, ...]]) -> str:
    """
    依据微信版本元组决定该执行的动作（纯函数，mac 可单测）。

    - None（读不到 / 未安装）→ 'install'（装 4.1.8）
    - >= (4,1,9)            → 'downgrade'（无障碍控件树被砍，卸载后装 4.1.8）
    - <= 4.1.8.x           → 'ok'（已验证可用基线）
    """
    if version_tuple is None:
        return "install"
    head = tuple(version_tuple[:3])
    head = head + (0,) * (3 - len(head))
    if head >= MIN_BLOCKED_VERSION:
        return "downgrade"
    if head < (4, 0, 0):
        return "install"  # 3.x 无 mmui::MainWindow，需安装 4.1.8
    return "ok"


def classify_elevation(is_admin: bool) -> Tuple[str, str]:
    """
    依据"当前进程是否提权/管理员"判定 elevation 检测的 (status, detail)（纯函数，mac 可单测）。

    - is_admin=True  → ('warn', 提示改用普通用户身份)：提权进程起讲述人/激活 UIA 会被
      系统 UIPI 权限隔离挡掉（Access denied）→ UIA 没真激活 → 微信登录后仍识别不到窗口。
      用 warn 不用 failed：极少数配置仍可用，但必须醒目提示。
    - is_admin=False → ('ok', 普通用户身份)：UIA 可正常激活。
    """
    if is_admin:
        return (
            "warn",
            "检测到以管理员/提权身份运行 → 讲述人/UIA 激活会被系统挡(Access denied) → "
            "微信登录后仍识别不到。请改用 **普通用户身份** 双击 start.bat 运行"
            "（不要右键'以管理员身份运行'）。",
        )
    return ("ok", "普通用户身份运行，UIA 可正常激活。")


def make_check(name: str, status: str, detail: str) -> Dict[str, str]:
    """构造单项检测结果。status ∈ {ok,fixed,warn,failed}。"""
    if status not in _STATUS_ICON:
        raise ValueError(f"非法 status: {status!r}")
    return {"name": name, "status": status, "detail": detail}


def compute_all_ok(checks: List[Dict[str, Any]]) -> bool:
    """全部检测都是 ok 或 fixed（无 warn、无 failed）才算 all_ok。"""
    return all(c.get("status") in ("ok", "fixed") for c in checks)


def has_failed(checks: List[Dict[str, Any]]) -> bool:
    """是否存在 failed 项（决定退出码：有 failed → 非0）。"""
    return any(c.get("status") == "failed" for c in checks)


def status_counts(checks: List[Dict[str, Any]]) -> Dict[str, int]:
    """按 status 归类计数（ok/fixed/warn/failed）。"""
    counts = {k: 0 for k in _STATUS_ICON}
    for c in checks:
        st = c.get("status")
        if st in counts:
            counts[st] += 1
    return counts


def build_report(checks: List[Dict[str, Any]], ts: Optional[int] = None) -> Dict[str, Any]:
    """把多项检测汇总成最终报告 dict。"""
    if ts is None:
        ts = int(time.time() * 1000)
    return {
        "ts": ts,
        "all_ok": compute_all_ok(checks),
        "counts": status_counts(checks),
        "checks": checks,
    }


def compute_exit_code(checks: List[Dict[str, Any]]) -> int:
    """退出码：有 failed → 1，否则（全 ok 或仅含 warn/fixed）→ 0。"""
    return 1 if has_failed(checks) else 0


# ─── 通用工具（Windows-only 动作放函数体内，try/except 包裹）──────────────────


def _is_windows() -> bool:
    return platform.system() == "Windows"


def _windll_available() -> bool:
    try:
        import ctypes

        return hasattr(ctypes, "windll")
    except Exception:
        return False


def _find_file(root: str, filename: str) -> Optional[str]:
    """在 root 下递归找第一个名为 filename 的文件。找不到返回 None。"""
    try:
        for dirpath, _dirs, files in os.walk(root):
            for f in files:
                if f.lower() == filename.lower():
                    return os.path.join(dirpath, f)
    except Exception:
        return None
    return None


def _find_files(root: str, filename: str) -> List[str]:
    """在 root 下递归找所有名为 filename 的文件路径。"""
    out: List[str] = []
    try:
        for dirpath, _dirs, files in os.walk(root):
            for f in files:
                if f.lower() == filename.lower():
                    out.append(os.path.join(dirpath, f))
    except Exception:
        pass
    return out


def _weixin_installed() -> bool:
    """Weixin.exe 是否存在（固定路径 + 安装根目录递归兜底）。"""
    if os.path.isfile(WEIXIN_EXE_DEFAULT):
        return True
    return _find_file(WEIXIN_INSTALL_ROOT, "Weixin.exe") is not None


def download_wechat_installer(
    dest_path: str = _INSTALLER_TMP,
    urls: Tuple[str, ...] = WECHAT_DOWNLOAD_URLS,
    min_size: int = MIN_DOWNLOAD_SIZE,
) -> Optional[str]:
    """
    按序从 urls 下载 4.1.8 安装包到 dest_path，校验体积 > min_size。
    成功返回 dest_path，全部失败返回 None。仅在真实自愈时调用（dry-run 不调）。
    """
    import urllib.request

    for url in urls:
        try:
            urllib.request.urlretrieve(url, dest_path)
            if os.path.isfile(dest_path) and os.path.getsize(dest_path) >= min_size:
                return dest_path
        except Exception:
            continue
    return None


def _run_silent(cmd: List[str], timeout: int = 600) -> Tuple[bool, str]:
    """跑外部命令（installer /S、uninstall /S 等）。返回 (成功, 说明)。异常吞掉。"""
    import subprocess

    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout)
        ok = proc.returncode == 0
        return ok, f"returncode={proc.returncode}"
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"


# ─── 8 项检测（每项：detect → fix → 修不了 prompt）─────────────────────────────


def check_os_session(dry_run: bool = False) -> Dict[str, str]:
    """1. OS/交互会话：必须 Windows + 有活动桌面（不可自愈）。"""
    if not _is_windows():
        return make_check(
            CHECK_NAMES[0],
            "failed",
            f"当前系统 {platform.system()} 非 Windows，微信 RPA 仅支持 Windows。"
            "请在 Windows 客户机上运行 agent。",
        )
    # 有活动桌面：用 GetSystemMetrics(SM_CXSCREEN) > 0 粗判（服务/无会话时为 0）。
    try:
        import ctypes

        cx = ctypes.windll.user32.GetSystemMetrics(0)
        if cx and cx > 0:
            return make_check(CHECK_NAMES[0], "ok", f"Windows 交互桌面会话正常（屏宽 {cx}px）。")
        return make_check(
            CHECK_NAMES[0],
            "failed",
            "未检测到交互桌面会话（屏宽=0，可能以服务/无人值守方式运行）。"
            "微信 RPA 必须在登录的交互桌面里跑，请用普通用户会话启动 agent。",
        )
    except Exception as exc:  # noqa: BLE001
        return make_check(CHECK_NAMES[0], "warn", f"无法判定桌面会话（{exc}），继续。")


def check_elevation(dry_run: bool = False) -> Dict[str, str]:
    """
    提权检测：当前进程是否以管理员/提权身份运行。

    真机踩坑：客户右键"以管理员身份运行"起 agent，start.bat 里讲述人激活那步报
    `Access is denied`（UIPI 权限隔离），UIA 没真激活 → 监听读不到微信窗口 →
    微信登录了也识别不到。普通用户身份跑就正常。故必须在此醒目提示。

    判定优先用 OpenProcessToken + GetTokenInformation(TokenElevation)（更准，
    能识别"以管理员身份运行"的提权态），失败回退 shell32.IsUserAnAdmin()。
    非 Windows / 查不到 → warn 并跳过（mac dry-run 优雅降级，不崩）。
    """
    name = CHECK_NAMES[8]
    if not _is_windows():
        return make_check(
            name,
            "warn",
            f"非 Windows（{platform.system()}），跳过提权检测（仅 Windows 客户机有效）。",
        )

    is_admin = _is_process_elevated()
    if is_admin is None:
        return make_check(
            name,
            "warn",
            "无法判定进程提权状态（token 查询失败），跳过。"
            "若讲述人激活报 Access denied，请改用普通用户身份运行。",
        )

    status, detail = classify_elevation(is_admin)
    return make_check(name, status, detail)


def _is_process_elevated() -> Optional[bool]:
    """
    查当前进程是否提权（管理员）。返回 True/False；查不到/非 Windows → None。
    Windows-only 调用全在函数体内 + try/except，mac 顶层 import 安全。
    """
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return None

    # 首选：OpenProcessToken + GetTokenInformation(TokenElevation)。
    try:
        TOKEN_QUERY = 0x0008
        TokenElevation = 20  # TOKEN_INFORMATION_CLASS.TokenElevation

        kernel32 = ctypes.windll.kernel32
        advapi32 = ctypes.windll.advapi32

        h_proc = kernel32.GetCurrentProcess()
        h_token = wintypes.HANDLE()
        if not advapi32.OpenProcessToken(h_proc, TOKEN_QUERY, ctypes.byref(h_token)):
            raise OSError("OpenProcessToken 失败")
        try:
            elevation = wintypes.DWORD(0)
            ret_len = wintypes.DWORD(0)
            ok = advapi32.GetTokenInformation(
                h_token,
                TokenElevation,
                ctypes.byref(elevation),
                ctypes.sizeof(elevation),
                ctypes.byref(ret_len),
            )
            if ok:
                return bool(elevation.value)
            raise OSError("GetTokenInformation 失败")
        finally:
            kernel32.CloseHandle(h_token)
    except Exception:
        pass

    # 回退：IsUserAnAdmin（管理员组 + 提权时为真）。
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return None


def check_wechat_installed(dry_run: bool = False) -> Dict[str, str]:
    """2. 微信安装：Weixin.exe 在不在；不在 → 下载 4.1.8 静默装。"""
    name = CHECK_NAMES[1]
    if _weixin_installed():
        return make_check(name, "ok", "已检测到 Weixin.exe。")

    if dry_run or not _is_windows():
        return make_check(
            name,
            "failed",
            "未检测到 Weixin.exe（dry-run/非 Windows 跳过自动安装）。"
            "真实运行将自动下载 4.1.8 静默安装。",
        )

    installer = download_wechat_installer()
    if not installer:
        return make_check(
            name,
            "failed",
            "微信未安装且 4.1.8 安装包下载失败（COS/官方源均不可达）。"
            "请手动安装微信 4.1.8 后重启 agent。",
        )
    ok, info = _run_silent([installer, "/S"])
    if ok and _weixin_installed():
        return make_check(name, "fixed", f"微信未安装 → 已静默安装 4.1.8（{info}）。")
    return make_check(
        name,
        "failed",
        f"微信 4.1.8 静默安装失败（{info}）。"
        "请右键 start.bat → 以管理员身份运行，或手动安装微信 4.1.8 后重启 agent。",
    )


def check_wechat_version(dry_run: bool = False) -> Dict[str, str]:
    """3. 微信版本：>=4.1.9 → 卸载+装4.1.8；=4.1.8 → ok；读不到 → warn。"""
    name = CHECK_NAMES[2]
    ver_str = get_weixin_version()
    parsed = _parse_version(ver_str)

    if parsed is None:
        # 装着但读不到版本 → 不硬阻断，给 warn（避免误杀）。
        if _weixin_installed():
            return make_check(
                name,
                "warn",
                f"读不到微信版本号（raw={ver_str!r}），跳过版本守卫。"
                "若 RPA 异常请人工确认版本 <=4.1.8。",
            )
        return make_check(
            name, "failed", "微信未安装，无法判定版本（应先过'微信安装'项）。"
        )

    action = decide_wechat_action(parsed)
    ver_show = ".".join(str(x) for x in parsed)

    if action == "ok":
        return make_check(name, "ok", f"微信版本 {ver_show} <=4.1.8，RPA 可用。")

    if action == "install":  # 理论上 parsed 非 None 不会走到这
        return make_check(name, "failed", "微信未安装（应先过'微信安装'项）。")

    # downgrade：>=4.1.9，无障碍控件树被砍，必须卸载后装 4.1.8。
    if dry_run or not _is_windows():
        return make_check(
            name,
            "failed",
            f"微信版本 {ver_show} >=4.1.9（无障碍控件树被砍，RPA 不可用）。"
            "dry-run/非 Windows 跳过自动降级；真实运行将卸载后装 4.1.8。",
        )

    uninstaller = _find_file(WEIXIN_INSTALL_ROOT, "Uninstall.exe")
    if uninstaller:
        _run_silent([uninstaller, "/S"], timeout=300)
        time.sleep(3)
    installer = download_wechat_installer()
    if not installer:
        return make_check(
            name,
            "failed",
            f"需把 {ver_show} 降级到 4.1.8，但安装包下载失败。"
            "请手动卸载并安装微信 4.1.8 后重启 agent。",
        )
    ok, info = _run_silent([installer, "/S"])
    new_ver = get_weixin_version()
    new_parsed = _parse_version(new_ver)
    if ok and new_parsed is not None and decide_wechat_action(new_parsed) == "ok":
        return make_check(
            name,
            "fixed",
            f"微信 {ver_show} → 已降级安装 4.1.8（现 {'.'.join(str(x) for x in new_parsed)}）。",
        )
    return make_check(
        name,
        "failed",
        f"微信降级到 4.1.8 失败（install {info}，现版本 {new_ver!r}）。"
        "请右键 start.bat → 以管理员身份运行，或手动卸载后安装微信 4.1.8 再重启。",
    )


def check_lock_update(dry_run: bool = False) -> Dict[str, str]:
    """4. 四层锁更新：Layer1 改名 .disabled / Layer2 icacls DENY / Layer3 域名防火墙 dldir1v6.qq.com / Layer4 注册表 AutoUpdate=0（幂等）。"""
    name = CHECK_NAMES[3]
    if not _is_windows():
        return make_check(name, "warn", "非 Windows，跳过锁更新（无 WeixinUpdate.exe）。")

    if not os.path.isdir(WEIXIN_INSTALL_ROOT):
        return make_check(name, "warn", f"未发现微信安装目录，跳过锁更新（{WEIXIN_INSTALL_ROOT}）。")

    enabled = _find_files(WEIXIN_INSTALL_ROOT, "WeixinUpdate.exe")
    if not enabled:
        return make_check(name, "ok", "WeixinUpdate.exe 已禁用（未发现启用的自动更新器）。")

    if dry_run:
        return make_check(
            name,
            "failed",
            f"发现 {len(enabled)} 个启用的 WeixinUpdate.exe（dry-run 不改）。"
            "真实运行将改名 .disabled + icacls DENY + 域名防火墙 + 注册表 AutoUpdate=0（四层锁）。",
        )

    import subprocess

    disabled_n = 0
    for exe_path in enabled:
        disabled_path = exe_path + ".disabled"

        # Layer 1: 改名 .disabled（防止更新器执行）
        try:
            os.replace(exe_path, disabled_path)
            disabled_n += 1
        except Exception:
            pass

        # Layer 2: icacls DENY（防止 .disabled 文件被重命名回来或执行）
        if os.path.exists(disabled_path):
            try:
                subprocess.run(
                    ["icacls", disabled_path, "/deny", "Everyone:(W,D)"],
                    capture_output=True, timeout=30,
                )
            except Exception:
                pass

        # 程序路径防火墙封禁（幂等：先删同名规则再加）
        try:
            subprocess.run(
                ["netsh", "advfirewall", "firewall", "delete", "rule",
                 "name=Block WeixinUpdate", f"program={exe_path}"],
                capture_output=True, timeout=30,
            )
            subprocess.run(
                ["netsh", "advfirewall", "firewall", "add", "rule",
                 "name=Block WeixinUpdate", "dir=out", "action=block",
                 f"program={exe_path}", "enable=yes"],
                capture_output=True, timeout=30,
            )
        except Exception:
            pass

    # Layer 3: 域名封禁 dldir1v6.qq.com（微信更新服务域名，比程序路径封禁更难绕过）
    # 规则名含域名使其出现在 netsh show rule name=all 输出中，便于验证
    try:
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "delete", "rule",
             "name=Block WeixinUpdate dldir1v6.qq.com"],
            capture_output=True, timeout=30,
        )
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule",
             "name=Block WeixinUpdate dldir1v6.qq.com",
             "dir=out", "action=block",
             "remoteip=any", "enable=yes",
             "description=Block WeChat auto-update domain dldir1v6.qq.com"],
            capture_output=True, timeout=30,
        )
    except Exception:
        pass

    # Layer 4: 注册表策略 AutoUpdate=0（HKLM\SOFTWARE\Policies\Tencent\WeChat\AutoUpdate）
    try:
        import winreg
        key = winreg.CreateKeyEx(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Policies\Tencent\WeChat",
            0,
            winreg.KEY_SET_VALUE,
        )
        winreg.SetValueEx(key, "AutoUpdate", 0, winreg.REG_DWORD, 0)
        winreg.CloseKey(key)
    except Exception:
        pass

    still = _find_files(WEIXIN_INSTALL_ROOT, "WeixinUpdate.exe")
    if not still:
        return make_check(
            name,
            "fixed",
            f"四层锁完成：{disabled_n} 个 WeixinUpdate.exe 已改名 .disabled + icacls DENY + "
            "域名防火墙 dldir1v6.qq.com + 注册表 AutoUpdate=0。",
        )
    return make_check(
        name,
        "warn",
        f"已禁用 {disabled_n} 个，仍有 {len(still)} 个改名失败（可能被占用）。"
        "建议关闭微信后重跑 preflight。",
    )


def check_wechat_login(dry_run: bool = False) -> Dict[str, str]:
    """5. 微信登录态：未登录 → 拉起微信 + 提示扫码。"""
    name = CHECK_NAMES[4]
    try:
        from find_weixin import get_main_window, login_window_present
    except Exception as exc:  # noqa: BLE001
        return make_check(name, "warn", f"无法导入寻址 API（{exc}），跳过登录态检测。")

    try:
        mw = get_main_window()
    except Exception as exc:  # noqa: BLE001
        return make_check(
            name, "warn", f"读取微信主窗口失败（{exc}，多为非 Windows/缺 pywinauto），跳过。"
        )

    if mw is not None:
        return make_check(name, "ok", "微信已登录（检测到 mmui::MainWindow）。")

    # 未见主窗口：可能停在登录窗口或微信没启动。
    login = False
    try:
        login = login_window_present()
    except Exception:
        login = False

    if not dry_run and _is_windows():
        # 尝试拉起微信（best-effort）。
        try:
            import subprocess

            if os.path.isfile(WEIXIN_EXE_DEFAULT):
                subprocess.Popen([WEIXIN_EXE_DEFAULT])
            else:
                found = _find_file(WEIXIN_INSTALL_ROOT, "Weixin.exe")
                if found:
                    subprocess.Popen([found])
        except Exception:
            pass

    detail = "微信未登录" + ("（停在登录窗口）" if login else "（未检测到主窗口）")
    return make_check(
        name,
        "warn",
        detail + "。已尝试拉起微信，请在客户机上 **扫码登录**，agent 将自动就绪。",
    )


def check_python_pywinauto(dry_run: bool = False) -> Dict[str, str]:
    """6. Python+pywinauto：import 测试；失败 → 提示重装 agent。"""
    name = CHECK_NAMES[5]
    try:
        import pywinauto  # noqa: F401

        ver = getattr(pywinauto, "__version__", "unknown")
        return make_check(name, "ok", f"pywinauto 可用（version={ver}）。")
    except Exception as exc:  # noqa: BLE001
        # mac/linux 开发环境本就无 pywinauto → warn；Windows 上缺失才是 failed。
        if not _is_windows():
            return make_check(
                name, "warn", f"pywinauto 在 {platform.system()} 不可用（开发环境正常）：{exc}"
            )
        return make_check(
            name,
            "failed",
            f"pywinauto import 失败（{exc}）。Python 运行时损坏，请重新下载安装包重装 agent。",
        )


def check_uia_narrator(dry_run: bool = False) -> Dict[str, str]:
    """7. UIA/讲述人激活：静默激活后能否读到主窗口。"""
    name = CHECK_NAMES[6]
    if dry_run or not _is_windows():
        return make_check(
            name, "warn", "dry-run/非 Windows 跳过讲述人激活（仅 Windows 真机有效）。"
        )

    # 检查 Narrator.exe 是否存在（LTSC/N/精简版 Windows 可能已移除）
    narrator_path = r"C:\Windows\System32\Narrator.exe"
    if not os.path.isfile(narrator_path):
        return make_check(
            name,
            "failed",
            "未找到 Narrator.exe（C:\\Windows\\System32\\Narrator.exe）。"
            "当前系统（LTSC/N 精简版/Ghost）已移除讲述人，无法激活 UIAutomation 控件树，"
            "微信 RPA 不可用。请使用完整版 Windows 10/11 家庭版/专业版。",
        )

    try:
        import subprocess

        subprocess.run(
            ["powershell", "-NoProfile", "-Command", "Start-Process Narrator"],
            capture_output=True, timeout=15,
        )
        time.sleep(2)
        subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Stop-Process -Name Narrator -Force -ErrorAction SilentlyContinue"],
            capture_output=True, timeout=15,
        )
        time.sleep(1)
    except Exception as exc:  # noqa: BLE001
        return make_check(
            name,
            "failed",
            f"讲述人激活失败（{exc}）。无法激活 UIAutomation 控件树，微信 RPA 不可用。"
            "请确认：1) 非管理员身份运行 start.bat；"
            "2) 组策略未禁用讲述人（gpedit.msc 搜索 Narrator）；"
            "3) Windows 为完整版（非 LTSC/N 精简版）。",
        )

    # 激活后验证 UIA 树可读（登录态下才有主窗口；未登录属正常，不在此判失败）
    try:
        from find_weixin import get_main_window

        mw = get_main_window()
        if mw is not None:
            return make_check(name, "ok", "讲述人激活成功，UIAutomation 控件树可读（检测到微信主窗口）。")
        return make_check(
            name,
            "warn",
            "讲述人已激活，但暂未读到微信主窗口（可能未登录/微信未启动），"
            "登录后即可生效。",
        )
    except Exception as exc:  # noqa: BLE001
        return make_check(
            name, "warn", f"激活后读主窗口异常（{exc}）。请确认 pywinauto 与微信登录态。"
        )


def check_middleware_health(middleware_url: str, dry_run: bool = False) -> Dict[str, str]:
    """8. 中台连通：GET <url>/health 或 /api/health（短超时）。"""
    name = CHECK_NAMES[7]
    if not middleware_url:
        return make_check(name, "warn", "未提供 middleware-url，跳过中台连通检测。")

    import urllib.request

    base = middleware_url.rstrip("/")
    last_err = ""
    for path in ("/health", "/api/health"):
        url = base + path
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=8) as resp:
                code = getattr(resp, "status", resp.getcode())
                if 200 <= int(code) < 500:
                    return make_check(name, "ok", f"中台可达（GET {path} → {code}）。")
                last_err = f"{path} → HTTP {code}"
        except Exception as exc:  # noqa: BLE001
            last_err = f"{path} → {type(exc).__name__}: {exc}"
            continue

    return make_check(
        name,
        "failed",
        f"中台不可达（{base}，{last_err}）。请检查客户机网络与 .env 中 ZENITHJOY_API_BASE 配置。",
    )


# ─── 编排：跑全部检测 → 汇总 → 打印 → 落盘 → 上报 ──────────────────────────────


def run_all_checks(middleware_url: str, dry_run: bool = False) -> List[Dict[str, str]]:
    """按序跑全部检测，每项独立 try/except 兜底（单项崩不拖垮整体）。

    elevation 排在 os_session 之后靠前：它影响后面 UIA/讲述人/登录项的成败。
    """
    runners: List[Tuple[str, Any]] = [
        ("os_session", lambda: check_os_session(dry_run)),
        ("elevation", lambda: check_elevation(dry_run)),
        ("wechat_installed", lambda: check_wechat_installed(dry_run)),
        ("wechat_version", lambda: check_wechat_version(dry_run)),
        ("lock_update", lambda: check_lock_update(dry_run)),
        ("wechat_login", lambda: check_wechat_login(dry_run)),
        ("python_pywinauto", lambda: check_python_pywinauto(dry_run)),
        ("uia_narrator", lambda: check_uia_narrator(dry_run)),
        ("middleware_health", lambda: check_middleware_health(middleware_url, dry_run)),
    ]
    checks: List[Dict[str, str]] = []
    for cname, run in runners:
        try:
            checks.append(run())
        except Exception as exc:  # noqa: BLE001 — 单项异常降级为 failed，不让体检整体崩
            checks.append(
                make_check(
                    cname,
                    "failed",
                    f"检测项内部异常：{type(exc).__name__}: {exc}",
                )
            )
    return checks


def print_report(report: Dict[str, Any]) -> None:
    """打印人类可读体检报告到 stdout。"""
    print("=" * 60)
    print("  ZenithJoy Agent 开机环境自检（preflight）")
    print("=" * 60)
    for c in report.get("checks", []):
        icon = _STATUS_ICON.get(c.get("status"), "?")
        print(f"  {icon} [{c.get('name')}] {c.get('detail')}")
    counts = report.get("counts", {})
    print("-" * 60)
    print(
        f"  汇总：ok={counts.get('ok', 0)} fixed={counts.get('fixed', 0)} "
        f"warn={counts.get('warn', 0)} failed={counts.get('failed', 0)}  "
        f"=> all_ok={report.get('all_ok')}"
    )
    print("=" * 60)
    sys.stdout.flush()


def write_report_json(report: Dict[str, Any], path: Optional[str] = None) -> bool:
    """把报告写本地 JSON。失败吞掉返回 False（不阻断体检）。"""
    if path is None:
        path = PREFLIGHT_JSON_PATH
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except Exception:
        pass
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def report_to_middleware(
    middleware_url: str, report: Dict[str, Any], agent_id: Optional[str] = None
) -> bool:
    """
    best-effort 上报报告到中台（复用 listen_chat.post_heartbeat，塞进 diag.preflight）。
    失败全部吞掉返回 False，绝不抛——上报不能拖垮启动。
    """
    if not middleware_url:
        return False
    try:
        from listen_chat import post_heartbeat

        hb = post_heartbeat(
            middleware_url,
            agent_id=agent_id or os.environ.get("ZENITHJOY_AGENT_ID"),
            diag={"preflight": report},
        )
        return bool(hb.get("ok"))
    except Exception:
        return False


# ─── CLI ─────────────────────────────────────────────────────────────────────


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="ZenithJoy Agent 开机环境自检 + 自愈")
    ap.add_argument(
        "--middleware-url",
        type=str,
        default=os.environ.get("ZENITHJOY_API_BASE", ""),
        help="中台地址（缺省取 env ZENITHJOY_API_BASE）",
    )
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="只检测不自愈、不下载、不卸载（给 CI / mac 跑）",
    )
    ap.add_argument(
        "--agent-id",
        type=str,
        default=os.environ.get("ZENITHJOY_AGENT_ID"),
        help="上报中台用的 agent 标识",
    )
    return ap.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)

    checks = run_all_checks(args.middleware_url, dry_run=args.dry_run)
    report = build_report(checks)

    print_report(report)
    wrote = write_report_json(report)
    if not wrote:
        print(f"[preflight] 写本地报告失败（{PREFLIGHT_JSON_PATH}），继续。", file=sys.stderr)

    reported = report_to_middleware(args.middleware_url, report, agent_id=args.agent_id)
    if not reported:
        print("[preflight] 上报中台失败/跳过（best-effort，不阻断）。", file=sys.stderr)

    return compute_exit_code(checks)


if __name__ == "__main__":
    sys.exit(main())
